let cartData = [
    {
        id: "5-125-6",
        product: "Juicy Fruit Gum",
        price: "$4.25",  
        quantity: 5
    },
    {
        id: "2-342-9",
        product: "Hershey Kisses",
        price: "$2.05",
        quantity: 2
    },
    {
        id: "4-588-1",
        product: "Bulk Strawberries",
        price: "$4.99",
        quantity: 1
    },
    {
        id: "7-830-0",
        product: "Cheerios",
        price: "$3.75",
        quantity: 1
    },
    {
        id: "6-715-9",
        product: "Granola",
        price: "$9.55",
        quantity: 2
    }];


    module.exports = cartData;
